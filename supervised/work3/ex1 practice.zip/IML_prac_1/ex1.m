function [] = ex1()
    % data values will be loaded to x and y
    load('reg_data_set_1.mat');
    
    figure();
    plot(x,y,'bo'); hold on;
    
    % simple linear regression
    p = polyfit(x,y,1);
    
    y = lfunc(p(1),p(2),x);
    plot(x,y,'r-');
    
    
end