function [y] = lfunc(w1,w0,x)    
    y = w1*x+w0;
end