function [w] = gdescent(x,y,learning_rate,threshold)
    min_error = realmax;
    o = ones(size(x,1),1);
    x = [o,x];
    x = x';   
    w = [1;1];
    n = 1/size(x,2);
    n2 = n/2;
    while(min_error > threshold)
        % calculate gradient
        
        divided_x = n*x);
        gradient_delta = divided_x*(x'*w-y);
        
        % update weights
        w = w + learning_rate*gradient_delta;
        
        % calculate new minimum
        min_error = (n2*((x*w)-y))'*((x*w')-y);
    end
    
end